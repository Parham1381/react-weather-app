export const defaultCity = 'Vancouver';
